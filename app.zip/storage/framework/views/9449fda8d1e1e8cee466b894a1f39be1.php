
<footer class="p-3 text-xs text-center text-slate-600 shrink-0 sm:p-4 sm:text-sm dark:text-slate-200">
    <p class="text-sm">© <?php echo e(date('Y')); ?> SistemaCREA. Todos los derechos reservados.</p>
    <p class="text-sm">Tola - Rivas, Nicaragua.</p>
</footer>
<?php /**PATH C:\Users\ezequ\Downloads\git\resources\views/layouts/footer.blade.php ENDPATH**/ ?>