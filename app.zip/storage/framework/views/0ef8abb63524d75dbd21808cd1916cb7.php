<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>" class=""> 
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo e(config('app.name', 'SistemaCREA')); ?></title>

    
    <link rel="preconnect" href="https://fonts.bunny.net">
    <link href="https://fonts.bunny.net/css?family=figtree:400,500,600&display=swap" rel="stylesheet" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <script src="https://cdn.jsdelivr.net/npm/flatpickr@4.6.13/dist/flatpickr.min.js"></script>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/flatpickr@4.6.13/dist/flatpickr.min.css">
    <script src="https://cdn.jsdelivr.net/npm/flatpickr@4.6.13/dist/l10n/es.js"></script>
    
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/sweetalert2@11/dist/sweetalert2.min.css">

    
    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>



    
    <script>
        function applyTheme() {
            const themePreference = localStorage.getItem('themePreference');
            const prefersDarkScheme = window.matchMedia('(prefers-color-scheme: dark)').matches;
            if (themePreference === 'dark' || (themePreference === 'system' && prefersDarkScheme) || (!themePreference && prefersDarkScheme)) {
                document.documentElement.classList.add('dark');
            } else {
                document.documentElement.classList.remove('dark');
            }
        }
        applyTheme();
        window.matchMedia('(prefers-color-scheme: dark)').addEventListener('change', () => {
             const currentPreference = localStorage.getItem('themePreference');
            if (currentPreference === 'system' || !currentPreference) applyTheme();
        });
    </script>
</head>
<body class="font-sans antialiased text-gray-800 transition-colors duration-300 bg-gradient-to-br from-slate-50 via-purple-50 to-pink-50 dark:from-slate-800 dark:via-purple-900 dark:to-pink-900 dark:text-slate-200">
    <div class="flex flex-col min-h-screen ">
        

        <?php echo $__env->make('layouts.navigation', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

        <?php if(isset($header)): ?>
        <header class="static top-0 z-40 ">
            <div class="flex flex-col w-full px-4 py-2 mx-auto gap-y-1 sm:flex-row sm:items-center sm:justify-between max-w-7xl sm:px-6 lg:px-8 sm:py-1">
                <?php echo e($header); ?>

            </div>
        </header>
        <?php endif; ?>

        <main class="flex-grow ">
            
            
            <?php echo e($slot); ?>

        </main>

        <?php echo $__env->make('layouts.footer', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    </div>

    
    <div id="global_toast_container" class="fixed top-20 right-5 z-[100] w-full max-w-xs sm:max-w-sm space-y-3"></div>

    
    <div id="sessionMessages" class="hidden"
         <?php if(session('success')): ?> data-success-message="<?php echo e(session('success')); ?>" <?php endif; ?>
         <?php if(session('error')): ?> data-error-message="<?php echo e(session('error')); ?>" <?php endif; ?>
         <?php if(session('warning')): ?> data-warning-message="<?php echo e(session('warning')); ?>" <?php endif; ?>
         <?php if(session('info')): ?> data-info-message="<?php echo e(session('info')); ?>" <?php endif; ?>
    ></div>


    
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

    
    <?php echo $__env->yieldPushContent('scripts'); ?>
</body>
</html>
<?php /**PATH C:\Users\ezequ\Downloads\git\resources\views/layouts/app.blade.php ENDPATH**/ ?>