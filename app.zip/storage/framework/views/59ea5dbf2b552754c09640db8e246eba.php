<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['active' => false, 'count' => null]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['active' => false, 'count' => null]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars); ?>

<?php
// Define the base classes shared by both active and inactive states
$baseClasses = 'group flex items-center px-1.5 py-2 rounded-full text-[10px] transition-colors duration-150 ease-in-out';

// Define classes for the inactive state
$inactiveClasses = 'text-slate-600 dark:text-slate-300 hover:bg-indigo-100 dark:hover:bg-slate-700 hover:text-indigo-700 dark:hover:text-indigo-400 transition-all duration-700 ease-in-out hover:scale-110 ';

// Define classes for the active state
$activeClasses = 'bg-violet-100/85 text-violet-800 dark:bg-purple-700/30 dark:text-white/85 font-semibold backdrop-blur-3xl';

// Combine base classes with state-specific classes
$classes = $baseClasses . ' ' . (($active ?? false) ? $activeClasses : $inactiveClasses);

// Define classes for the count badge
$countBaseClasses = 'text-[10px] px-1 py-0.5 rounded-3xl ml-0.5 transition-opacity duration-300 ease-in';
$countActiveClasses = 'bg-gradient-to-br from-violet-700 via-purple-700 to-purple-800 text-white dark:bg-indigo-500 dark:text-white';
$countInactiveClasses = 'bg-gradient-to-br from-violet-700 via-purple-700 to-purple-800 text-white dark:bg-indigo-600 dark:text-indigo-100 group-hover:bg-indigo-600 dark:group-hover:bg-indigo-500 ';
$countClasses = $countBaseClasses . ' ' . (($active ?? false) ? $countActiveClasses : $countInactiveClasses);

?>

<a <?php echo e($attributes->merge(['class' => $classes])); ?>>
    
    
    <?php echo e($slot); ?>


    <?php if($count !== null && $count > 0): ?>
        <span class="<?php echo e($countClasses); ?>">
            <?php echo e($count); ?>

        </span>
    <?php endif; ?>
</a>
<?php /**PATH C:\Users\ezequ\Downloads\git\resources\views/components/nav-link.blade.php ENDPATH**/ ?>