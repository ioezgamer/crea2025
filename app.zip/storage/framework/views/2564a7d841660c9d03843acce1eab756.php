
<?php if($participantes->isNotEmpty()): ?>
    <div class="mt-6 overflow-x-auto overflow-y-auto max-h-[70vh] shadow-lg rounded-3xl border-x-2 border-y-2 border-gray-200 bg-white">

        <table class="min-w-full text-sm divide-y divide-gray-600">
            <thead class="bg-gray-200">
                <tr class="text-sm uppercase font-medium text-gray-600">
                    <th class="sticky top-0 left-0 z-20 px-4 py-3 text-left bg-gray-200 border-r-2 border-white">Nombres y apellidos</th>
                    <th class="sticky top-0 z-10 px-3 py-3 text-left bg-gray-200 border-r-2 border-white">Género</th>
                    <th class="sticky top-0 z-10 px-3 py-3 text-left bg-gray-200 border-r-2 border-white">Grado</th>
                    <th class="sticky top-0 z-10 px-3 py-3 text-left bg-gray-200 border-r-2 border-white">Días Esperados</th>
                        
                    <?php $__currentLoopData = $diasSemana; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $diaNombre => $fechaDia): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <th class="sticky top-0 left-0 z-20 px-2 py-3 text-center bg-gray-200 whitespace-nowrap border-r-2 border-white">
                            <?php
                                $abreviaturas = ['Lunes'=>'Lun','Martes'=>'Mar','Miércoles'=>'Mié','Jueves'=>'Jue','Viernes'=>'Vie'];
                            ?>
                            <?php echo e($abreviaturas[$diaNombre] ?? mb_substr($diaNombre, 0, 3)); ?>

                            <span class="block text-xxs"><?php echo e(\Carbon\Carbon::parse($fechaDia)->format('d')); ?></span>
                        </th>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <th class="sticky top-0 z-10 px-3 py-3 text-center bg-gray-200 border-r-2 border-white">Total P.</th>
                    <th class="sticky top-0 z-10 px-3 py-3 text-center bg-gray-200 border-r-2 border-white">% Asist.</th>
                </tr>
            </thead>
            <tbody class="divide-y divide-gray-200 ">
                <?php $__currentLoopData = $participantes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $participante): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr class="group" id="fila-participante-<?php echo e($participante->participante_id); ?>">
                        <td class="sticky left-0 z-10 px-4 py-3 text-gray-900  whitespace-nowrap bg-white group-hover:bg-sky-100">
                            <?php echo e($participante->primer_nombre_p); ?> <?php echo e($participante->segundo_nombre_p ?? ''); ?> <?php echo e($participante->primer_apellido_p); ?> <?php echo e($participante->segundo_apellido_p ?? ''); ?>

                            <span class="ml-2 text-xs save-feedback"></span>
                        </td>
                        <td class="px-3 py-3 text-gray-600 group-hover:bg-sky-100"><?php echo e($participante->genero); ?></td>
                        <td class="px-3 py-3 text-gray-600 group-hover:bg-sky-100"><?php echo e($participante->grado_p ?? 'N/A'); ?></td>
                        
                        <td class="px-3 py-3 text-xs text-gray-600 group-hover:bg-sky-100">
                            <?php if($participante->dias_de_asistencia_al_programa): ?>
                                <?php
                                    $diasEsperados = explode(',', $participante->dias_de_asistencia_al_programa);
                                ?>
                                <?php $__currentLoopData = $diasEsperados; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $de): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php
                                        $dia = strtolower(trim($de));
                                        $color = match($dia) {
                                            'lunes' => 'bg-red-200',
                                            'martes' => 'bg-yellow-200',
                                            'miércoles', 'miercoles' => 'bg-green-200',
                                            'jueves' => 'bg-blue-200',
                                            'viernes' => 'bg-purple-200',
                                            default => 'bg-gray-200',
                                        };
                                    ?>
                                    <span class="inline-block px-1 py-0.5 <?php echo e($color); ?> rounded text-xs mr-1">
                                        <?php echo e(mb_substr(ucfirst($dia), 0, 3)); ?>

                                    </span>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php else: ?>
                                N/A
                            <?php endif; ?>
                        </td>


                        <?php $__currentLoopData = $diasSemana; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $diaNombre => $fechaDia): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <td class="px-2 py-3 text-center group-hover:bg-sky-100">
                                <?php
                                    $estado = $asistencias[$participante->participante_id][$diaNombre] ?? 'Ausente';
                                    $color = match($estado) {
                                        'Presente' => 'bg-green-200',
                                        'Justificado' => 'bg-yellow-200',
                                        'Ausente' => 'bg-red-200',
                                        default => 'bg-white',
                                    };
                                ?>

                                <select name="asistencia_individual"
                                    class="w-10 p-1 text-xs border-gray-300 rounded-3xl focus:border-blue-500 focus:ring-indigo-500 asistencia-select <?php echo e($color); ?>"
                                    data-participante-id="<?php echo e($participante->participante_id); ?>"
                                    data-fecha-asistencia="<?php echo e($fechaDia); ?>"
                                    data-dia-nombre="<?php echo e($diaNombre); ?>">
                                    <option value="Presente" <?php echo e($estado == 'Presente' ? 'selected' : ''); ?>>P</option>
                                    <option value="Ausente" <?php echo e($estado == 'Ausente' ? 'selected' : ''); ?>>A</option>
                                    <option value="Justificado" <?php echo e($estado == 'Justificado' ? 'selected' : ''); ?>>J</option>
                                </select>

                            </td>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <td class="px-3 py-3 text-center total-asistido group-hover:bg-sky-100" data-participante-id="<?php echo e($participante->participante_id); ?>"><?php echo e($participante->totalAsistido ?? 0); ?></td>
                        <td class="px-3 py-3 text-center porcentaje-asistencia group-hover:bg-sky-100" data-participante-id="<?php echo e($participante->participante_id); ?>"><?php echo e($participante->porcentajeAsistencia ?? 0); ?>%</td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
<?php else: ?>
    <div class="p-6 mt-6 text-sm text-gray-500 bg-white rounded-3xl shadow-sm">
        Seleccione todos los filtros (Programa, Lugar, Grado y Semana) para cargar la lista de participantes.
        <?php if(isset($selectedPrograma) && $selectedPrograma && isset($selectedLugar) && $selectedLugar && isset($selectedGrado) && $selectedGrado): ?>
            <br>No se encontraron participantes para los filtros seleccionados.
        <?php endif; ?>
    </div>
<?php endif; ?>
<?php /**PATH C:\Users\ezequ\Downloads\git\resources\views/asistencia/partials/tabla_asistencia.blade.php ENDPATH**/ ?>