<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <div class="flex items-center justify-between w-full px-4 py-6 mx-auto max-w-7xl sm:px-6 lg:px-8">
            <h2 class="text-2xl font-bold text-transparent lg:text-3xl bg-clip-text bg-gradient-to-r from-indigo-600 via-purple-600 to-pink-500">
                <?php echo e(__('Registro de asistencia')); ?>

            </h2>
            <?php if (isset($component)) { $__componentOriginal2ad463efb6f5ef4e768c2d1df819f275 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal2ad463efb6f5ef4e768c2d1df819f275 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.boton-regresar','data' => ['onclick' => 'window.location.href=\''.e(route('dashboard')).'\'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('boton-regresar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['onclick' => 'window.location.href=\''.e(route('dashboard')).'\'']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal2ad463efb6f5ef4e768c2d1df819f275)): ?>
<?php $attributes = $__attributesOriginal2ad463efb6f5ef4e768c2d1df819f275; ?>
<?php unset($__attributesOriginal2ad463efb6f5ef4e768c2d1df819f275); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal2ad463efb6f5ef4e768c2d1df819f275)): ?>
<?php $component = $__componentOriginal2ad463efb6f5ef4e768c2d1df819f275; ?>
<?php unset($__componentOriginal2ad463efb6f5ef4e768c2d1df819f275); ?>
<?php endif; ?>
        </div>
     <?php $__env->endSlot(); ?>

    <div class="min-h-screen py-8 bg-gradient-to-br from-slate-50 via-purple-50 to-pink-50 dark:from-slate-800 dark:via-purple-900 dark:to-pink-900">
        <div class="max-w-full px-2 mx-auto sm:px-4 lg:px-6">
            
            <div class="p-4 mb-6 border-transparent shadow-lg bg-gradient-to-r from-indigo-600/5 via-purple-600/5 to-pink-500/5 dark:bg-slate-800/80 backdrop-blur-sm rounded-3xl sm:p-6">
                <div class="grid items-end grid-cols-1 gap-4 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-5">
                    <div>
                        <label for="filtro_programa" class="block mb-1 text-xs font-medium text-slate-700 dark:text-slate-300">Programa <span class="text-red-500">*</span></label>
                        <select name="programa" id="filtro_programa" class="mt-1 block w-full rounded-3xl border-slate-300 dark:border-slate-600 dark:bg-slate-700 dark:text-slate-300 text-sm shadow-sm focus:border-indigo-500 dark:focus:border-indigo-600 focus:ring-2 focus:ring-indigo-500 dark:focus:ring-indigo-600 py-2.5 pl-3 pr-8 transition duration-150 ease-in-out">
                            <option value="">Seleccione Programa...</option>
                            <?php $__currentLoopData = $programOptions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $prog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($prog); ?>" <?php echo e($selectedPrograma == $prog ? 'selected' : ''); ?>><?php echo e($prog); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <div>
                        <label for="filtro_lugar" class="block mb-1 text-xs font-medium text-slate-700 dark:text-slate-300">Lugar <span class="text-red-500">*</span></label>
                        <select name="lugar_de_encuentro_del_programa" id="filtro_lugar" class="mt-1 block w-full rounded-3xl border-slate-300 dark:border-slate-600 dark:bg-slate-700 dark:text-slate-300 text-sm shadow-sm focus:border-indigo-500 dark:focus:border-indigo-600 focus:ring-2 focus:ring-indigo-500 dark:focus:ring-indigo-600 py-2.5 pl-3 pr-8 transition duration-150 ease-in-out" disabled>
                            <option value="">Seleccione Lugar...</option>
                            <?php $__currentLoopData = $lugarOptions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lugar): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                                <option value="<?php echo e($lugar); ?>" <?php echo e($selectedLugar == $lugar ? 'selected' : ''); ?>><?php echo e($lugar); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <div>
                        <label for="filtro_grado" class="block mb-1 text-xs font-medium text-slate-700 dark:text-slate-300">Grado <span class="text-red-500">*</span></label>
                        <select name="grado_p" id="filtro_grado" class="mt-1 block w-full rounded-3xl border-slate-300 dark:border-slate-600 dark:bg-slate-700 dark:text-slate-300 text-sm shadow-sm focus:border-indigo-500 dark:focus:border-indigo-600 focus:ring-2 focus:ring-indigo-500 dark:focus:ring-indigo-600 py-2.5 pl-3 pr-8 transition duration-150 ease-in-out" disabled>
                            <option value="">Seleccione Grado...</option>
                             <?php $__currentLoopData = $gradoOptions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $grado): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                                <option value="<?php echo e($grado); ?>" <?php echo e($selectedGrado == $grado ? 'selected' : ''); ?>><?php echo e($grado); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <div>
                        <label for="filtro_tipo_asistencia" class="block mb-1 text-xs font-medium text-slate-700 dark:text-slate-300">Tipo Asistencia <span class="text-red-500">*</span></label>
                        <select name="tipo_asistencia" id="filtro_tipo_asistencia" class="mt-1 block w-full rounded-3xl border-slate-300 dark:border-slate-600 dark:bg-slate-700 dark:text-slate-300 text-sm shadow-sm focus:border-indigo-500 dark:focus:border-indigo-600 focus:ring-2 focus:ring-indigo-500 dark:focus:ring-indigo-600 py-2.5 pl-3 pr-8 transition duration-150 ease-in-out">
                            <option value="semanal" <?php echo e(($selectedTipoAsistencia ?? 'semanal') == 'semanal' ? 'selected' : ''); ?>>Semanal</option>
                            <option value="diaria" <?php echo e(($selectedTipoAsistencia ?? 'semanal') == 'diaria' ? 'selected' : ''); ?>>Diaria</option>
                        </select>
                    </div>
                    <div>
                        <label for="filtro_fecha" class="block mb-1 text-xs font-medium text-slate-700 dark:text-slate-300"><span id="label_fecha">Semana (Lunes)</span> <span class="text-red-500">*</span></label>
                        <input type="date" name="fecha" id="filtro_fecha" value="<?php echo e($fechaInput ?? now()->startOfWeek()->format('Y-m-d')); ?>" class="mt-1 block w-full rounded-3xl border-slate-300 dark:border-slate-600 dark:bg-slate-700 dark:text-slate-300 text-sm shadow-sm focus:border-indigo-500 dark:focus:border-indigo-600 focus:ring-2 focus:ring-indigo-500 dark:focus:ring-indigo-600 py-2.5 placeholder-slate-400 dark:placeholder-slate-500 dark:[color-scheme:dark]">
                    </div>
                </div>
                <div class="mt-4 text-right">
                    <button type="button" id="btn_cargar_participantes" class="inline-flex items-center px-5 py-2.5 bg-gradient-to-r from-indigo-600 to-purple-600 border border-transparent rounded-3xl font-semibold text-xs text-white uppercase tracking-widest hover:from-indigo-700 hover:to-purple-700 focus:outline-none focus:ring-2 focus:ring-purple-500 focus:ring-offset-2 dark:focus:ring-offset-slate-900 transition ease-in-out duration-150 shadow-md hover:shadow-lg disabled:opacity-50 disabled:cursor-not-allowed" disabled>
                        <svg id="spinner_cargar" class="hidden w-4 h-4 mr-2 -ml-1 text-white animate-spin" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                            <circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4"></circle>
                            <path class="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                        </svg>
                        Cargar Participantes
                    </button>
                </div>
            </div>

            
            <div id="global_feedback_messages" class="mb-4"></div>
            <?php if($errors->any()): ?>
                <div class="p-4 mb-6 text-xs text-red-700 border-l-4 border-red-500 shadow-md bg-red-50/70 dark:bg-red-700/30 backdrop-blur-md dark:border-red-600 dark:text-red-200 rounded-xl">
                    <p class="font-semibold text-red-800 dark:text-red-100">Por favor corrige los siguientes errores:</p>
                    <ul class="list-disc ml-5 mt-1 space-y-0.5">
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            <?php endif; ?>
            <?php if(session('success')): ?>
                <div class="p-4 mb-6 text-xs text-green-700 border-l-4 border-green-500 shadow-md bg-green-50/70 dark:bg-green-700/30 backdrop-blur-md dark:border-green-600 dark:text-green-200 rounded-xl">
                    <?php echo e(session('success')); ?>

                </div>
            <?php endif; ?>

            
            <div id="tabla_asistencia_container">
                <?php if($participantes->isNotEmpty()): ?>
                    
                    <?php echo $__env->make('asistencia.partials.tabla_asistencia', [
                        'participantes' => $participantes,
                        'diasSemana' => $diasSemana,
                        'asistencias' => $asistencias,
                        'selectedPrograma' => $selectedPrograma,
                        'fechaInput' => $fechaInput,
                        'selectedLugar' => $selectedLugar,
                        'selectedGrado' => $selectedGrado,
                        'selectedTipoAsistencia' => $selectedTipoAsistencia ?? 'semanal'
                    ], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                <?php else: ?>
                    <div class="p-8 mt-6 text-center shadow-lg bg-white/70 dark:bg-slate-800/80 backdrop-blur-lg rounded-2xl">
                        <svg class="w-12 h-12 mx-auto mb-3 text-slate-400 dark:text-slate-500" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" aria-hidden="true">
                           <path stroke-linecap="round" stroke-linejoin="round" d="M11.25 11.25l.041-.02a.75.75 0 011.063.852l-.708 2.836a.75.75 0 001.063.853l.041-.021M21 12a9 9 0 11-18 0 9 9 0 0118 0zm-9-3.75h.008v.008H12V8.25z" />
                        </svg>
                        <p class="text-sm text-slate-600 dark:text-slate-400">
                            Seleccione todos los filtros (Programa, Lugar, Grado, Tipo Asistencia y Fecha) y presione "Cargar Participantes" para mostrar la tabla de asistencia.
                        </p>
                    </div>
                <?php endif; ?>
            </div>

            
            <div id="report_button_container" class="mt-6 text-center <?php echo e(!$selectedPrograma || $participantes->isEmpty() ? 'hidden' : ''); ?>">
                 <a href="#" id="link_generar_reporte" class="inline-flex items-center justify-center py-2.5 px-6 bg-gradient-to-r from-green-500 to-emerald-600 border border-transparent rounded-xl font-semibold text-sm text-white shadow-md hover:shadow-lg hover:from-green-600 hover:to-emerald-700 focus:outline-none focus:ring-2 focus:ring-offset-2 dark:focus:ring-offset-slate-900 focus:ring-emerald-500 transition ease-in-out duration-150">
                    <svg class="w-5 h-5 mr-2 -ml-1" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 17v-2m3 2v-4m3 4v-6m2 10H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"></path></svg>
                    Generar Reporte de Asistencia
                </a>
            </div>
        </div>
    </div>



<div id="asistenciaConfig" class="hidden"
     data-opciones-lugares-url="<?php echo e(route('asistencia.opciones.lugares')); ?>"
     data-opciones-grados-url="<?php echo e(route('asistencia.opciones.grados')); ?>"
     data-opciones-participantes-url="<?php echo e(route('asistencia.opciones.participantes')); ?>"
     data-store-individual-url="<?php echo e(route('asistencia.storeIndividual')); ?>"
     data-reporte-url-base="<?php echo e(route('asistencia.reporte')); ?>"
     data-csrf-token="<?php echo e(csrf_token()); ?>"
     data-initial-selected-programa="<?php echo e($selectedPrograma ?? ''); ?>"
     data-initial-selected-lugar="<?php echo e($selectedLugar ?? ''); ?>"
     data-initial-selected-grado="<?php echo e($selectedGrado ?? ''); ?>"
></div>


<style>
    .text-xxs { font-size: 0.65rem; line-height: 0.85rem; }
    .sticky.left-0 {
        position: -webkit-sticky; /* For Safari */
        position: sticky;
        left: 0;
        z-index: 10;
    }
    thead th.sticky.left-0 {
        z-index: 20 !important; /* Ensure header is above body cells */
    }
    /* Custom scrollbar for Webkit browsers */
    .overflow-x-auto::-webkit-scrollbar { height: 8px; }
    .overflow-x-auto::-webkit-scrollbar-track { background: #f1f5f9; border-radius: 10px; }
    .dark .overflow-x-auto::-webkit-scrollbar-track { background: #334155; } /* slate-700 */
    .overflow-x-auto::-webkit-scrollbar-thumb { background: #cbd5e1; border-radius: 10px; }
    .dark .overflow-x-auto::-webkit-scrollbar-thumb { background: #475569; } /* slate-600 */
    .overflow-x-auto::-webkit-scrollbar-thumb:hover { background: #94a3b8; }
    .dark .overflow-x-auto::-webkit-scrollbar-thumb:hover { background: #64748b; } /* slate-500 */

    /* Specific style for date input in dark mode to ensure text is visible */
    .dark input[type="date"]::-webkit-calendar-picker-indicator {
        filter: invert(1);
    }
</style>

    <?php $__env->startPush('scripts'); ?>
        <?php echo app('Illuminate\Foundation\Vite')(['resources/js/pages/asistencia-attendance.js']); ?>
    <?php $__env->stopPush(); ?>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH C:\Users\ezequ\Downloads\git\resources\views/asistencia/attendance.blade.php ENDPATH**/ ?>