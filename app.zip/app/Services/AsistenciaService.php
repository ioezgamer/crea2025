<?php

namespace App\Services;

use App\Models\Asistencia;
use App\Models\Participante;
use Carbon\Carbon;
use Illuminate\Support\Collection;

/**
 * Servicio para manejar la lógica de negocio relacionada con las asistencias.
 */
class AsistenciaService
{
    /**
     * Obtiene los días de la semana para el registro de asistencia.
     *
     * @param Carbon $fechaReferencia
     * @param string $tipoAsistencia ('semanal' o 'diaria')
     * @return array
     */
    public function getDiasParaAsistencia(Carbon $fechaReferencia, string $tipoAsistencia): array
    {
        $dias = [];
        if ($tipoAsistencia === 'semanal') {
            $inicioSemana = $fechaReferencia->copy()->startOfWeek();
            for ($i = 0; $i < 5; $i++) {
                $fecha = $inicioSemana->copy()->addDays($i);
                $dias[$fecha->translatedFormat('l')] = $fecha->format('Y-m-d');
            }
        } elseif ($tipoAsistencia === 'diaria') {
            $dias[$fechaReferencia->translatedFormat('l')] = $fechaReferencia->format('Y-m-d');
        }
        return $dias;
    }

    /**
     * Carga los participantes y sus registros de asistencia para un rango de fechas.
     *
     * @param array $filters
     * @return array [Collection $participantes, array $asistenciasData]
     */
    public function cargarParticipantesYAsistencias(array $filters): array
    {
        $query = Participante::query()->where('activo', true)
            ->filterByPrograma($filters['programa'])
            ->filterByLugar($filters['lugar_de_encuentro_del_programa'] ?? null)
            ->filterByGrado($filters['grado_p'] ?? null);

        $fechaCarbon = Carbon::parse($filters['fecha']);
        $diasSemana = $this->getDiasParaAsistencia($fechaCarbon, $filters['tipo_asistencia']);

        $fechaInicioRango = min($diasSemana);
        $fechaFinRango = max($diasSemana);

        $participantes = $query->with(['asistencias' => function ($q) use ($fechaInicioRango, $fechaFinRango) {
            $q->whereBetween('fecha_asistencia', [$fechaInicioRango, $fechaFinRango]);
        }])->orderBy('primer_apellido_p')->orderBy('primer_nombre_p')->get();

        $asistenciasData = $this->mapearAsistencias($participantes, $diasSemana);

        return [$participantes, $asistenciasData, $diasSemana];
    }

    /**
     * Mapea las asistencias a un formato fácil de usar y calcula los totales.
     *
     * @param Collection $participantes
     * @param array $diasSemana
     * @return array
     */
    private function mapearAsistencias(Collection $participantes, array $diasSemana): array
    {
        $asistenciasData = [];
        foreach ($participantes as $participante) {
            $asistenciasParticipante = $participante->asistencias->keyBy(fn($item) => Carbon::parse($item->fecha_asistencia)->format('Y-m-d'));
            $totalAsistido = 0;

            foreach ($diasSemana as $diaNombre => $fechaDia) {
                $estado = $asistenciasParticipante->get($fechaDia)?->estado ?? 'Ausente';
                $asistenciasData[$participante->participante_id][$diaNombre] = $estado;
                if ($estado === 'Presente') {
                    $totalAsistido++;
                }
            }
            $participante->totalAsistido = $totalAsistido;
            $participante->porcentajeAsistencia = count($diasSemana) > 0 ? round(($totalAsistido / count($diasSemana)) * 100) : 0;
        }
        return $asistenciasData;
    }

    /**
     * Calcula estadísticas de asistencia por día.
     *
     * @param Collection $participantes
     * @param array $asistenciasData
     * @param array $diasSemana
     * @return array
     */
    public function calcularEstadisticas(Collection $participantes, array $asistenciasData, array $diasSemana): array
    {
        $estadisticas = [
            'porDia' => [],
            'totalParticipantes' => $participantes->count(),
            'promedioGeneral' => 0,
        ];

        foreach ($diasSemana as $diaNombre => $fechaDia) {
            $estadisticas['porDia'][$diaNombre] = ['Presente' => 0, 'Ausente' => 0, 'Justificado' => 0, 'Total' => 0];
        }

        foreach ($participantes as $p) {
            foreach ($diasSemana as $diaNombre => $fechaDia) {
                $estado = $asistenciasData[$p->participante_id][$diaNombre] ?? 'Ausente';
                if (isset($estadisticas['porDia'][$diaNombre][$estado])) {
                    $estadisticas['porDia'][$diaNombre][$estado]++;
                }
                $estadisticas['porDia'][$diaNombre]['Total']++;
            }
        }

        $sumaPorcentajes = $participantes->sum('porcentajeAsistencia');
        $estadisticas['promedioGeneral'] = $estadisticas['totalParticipantes'] > 0 ? round($sumaPorcentajes / $estadisticas['totalParticipantes']) : 0;

        return $estadisticas;
    }
}
