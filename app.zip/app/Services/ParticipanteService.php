<?php

namespace App\Services;

use App\Models\Participante;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

/**
 * Servicio para manejar la lógica de negocio relacionada con los Participantes.
 */
class ParticipanteService
{
    /**
     * Prepara los datos necesarios para los formularios de creación y edición de participantes.
     *
     * @return array
     */
    public function getFormData(): array
    {
        $comunidades = $this->getUnifiedComunidadesList();
        $sector_economico = Participante::distinct()->pluck('sector_economico_tutor')->filter()->sort()->values();
        $nivel_educacion = Participante::distinct()->pluck('nivel_de_educacion_formal_adquirido_tutor')->filter()->sort()->values();

        $tipos_tutor_db = Participante::distinct()->pluck('tutor_principal')->filter()->sort()->values();
        $tipos_tutor_estaticos = ['Otro', 'Tío', 'Primo'];
        $tipos_tutor = $tipos_tutor_db->merge($tipos_tutor_estaticos)->unique()->sort()->values();

        $tiposParticipanteDB = Participante::distinct()->whereNotNull('participante')->where('participante', '!=', '')->pluck('participante')->filter()->sort()->values();
        $tiposParticipanteEstaticos = ['Preescolar (o menos)', 'Primaria', 'Secundaria', 'Adulto'];
        $tiposParticipante = collect($tiposParticipanteEstaticos)->merge($tiposParticipanteDB)->unique()->sort()->values();

        $programaOptionsList = $this->getDistinctColumnValues('programa');
        $subProgramaOptionsList = $this->getDistinctColumnValues('programas');

        $diasOptionsList = ['Lunes', 'Martes', 'Miércoles', 'Jueves', 'Viernes'];
        $lugaresDeEncuentro = Participante::select('lugar_de_encuentro_del_programa as lugar')->whereNotNull('lugar_de_encuentro_del_programa')->where('lugar_de_encuentro_del_programa', '!=', '')->distinct()->orderBy('lugar')->pluck('lugar');

        return compact(
            'comunidades', 'tipos_tutor', 'sector_economico', 'nivel_educacion',
            'programaOptionsList', 'subProgramaOptionsList', 'diasOptionsList', 'lugaresDeEncuentro',
            'tiposParticipante'
        );
    }

    /**
     * Procesa y prepara los datos del request antes de guardarlos en la base de datos.
     *
     * @param array $validatedData
     * @param Request $request
     * @return array
     */
    public function processRequestData(array $validatedData, Request $request): array
    {
        // Lógica para campos con opción "Otra"
        if ($request->input('lugar_de_encuentro_del_programa') === '_OTRA_') {
            $validatedData['lugar_de_encuentro_del_programa'] = $request->input('nueva_lugar_de_encuentro_del_programa');
        }
        if ($request->input('comunidad_p') === '_OTRA_') {
            $validatedData['comunidad_p'] = $request->input('nueva_comunidad_p');
        }
        if ($request->input('comunidad_tutor') === '_OTRA_') {
            $validatedData['comunidad_tutor'] = $request->input('nueva_comunidad_tutor');
        }

        // Lógica para subprogramas (programas)
        $selectedSubprograms = $validatedData['programas'] ?? [];
        $newSubprogram = trim($request->input('nuevo_subprograma', ''));
        if (!empty($newSubprogram) && !in_array($newSubprogram, $selectedSubprograms)) {
            $selectedSubprograms[] = $newSubprogram;
        }
        $finalSubprograms = array_filter($selectedSubprograms, fn($v) => !empty($v) && $v !== '_OTROS_');
        $validatedData['programas'] = implode(',', $finalSubprograms);

        // Convertir arrays a strings CSV
        $validatedData['programa'] = implode(',', (array)($validatedData['programa'] ?? []));
        $validatedData['dias_de_asistencia_al_programa'] = implode(',', (array)($validatedData['dias_de_asistencia_al_programa'] ?? []));

        return $validatedData;
    }


    /**
     * Obtiene una lista unificada y ordenada de todas las comunidades.
     *
     * @return \Illuminate\Support\Collection
     */
    private function getUnifiedComunidadesList()
    {
        $comunidades_p = Participante::query()->select('comunidad_p as comunidad')->whereNotNull('comunidad_p')->where('comunidad_p', '!=', '');
        return Participante::query()->select('comunidad_tutor as comunidad')->whereNotNull('comunidad_tutor')->where('comunidad_tutor', '!=', '')
            ->union($comunidades_p)
            ->distinct()
            ->orderBy('comunidad')
            ->pluck('comunidad');
    }

    /**
     * Obtiene valores únicos de una columna que almacena datos separados por comas.
     *
     * @param string $columnName
     * @return \Illuminate\Support\Collection
     */
    private function getDistinctColumnValues(string $columnName): \Illuminate\Support\Collection
    {
        return DB::table('participantes')
            ->whereNotNull($columnName)
            ->where($columnName, '!=', '')
            ->pluck($columnName)
            ->flatMap(fn($item) => explode(',', $item))
            ->map(fn($p) => trim($p))
            ->filter()
            ->unique()
            ->sort()
            ->values();
    }
}
