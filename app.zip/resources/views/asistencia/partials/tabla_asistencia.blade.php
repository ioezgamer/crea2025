{{-- resources/views/asistencia/partials/tabla_asistencia.blade.php --}}
@if ($participantes->isNotEmpty())
    <div class="mt-6 overflow-x-auto overflow-y-auto max-h-[70vh] shadow-lg rounded-3xl border-x-2 border-y-2 border-gray-200 bg-white">

        <table class="min-w-full text-sm divide-y divide-gray-600">
            <thead class="bg-gray-200">
                <tr class="text-sm uppercase font-medium text-gray-600">
                    <th class="sticky top-0 left-0 z-20 px-4 py-3 text-left bg-gray-200 border-r-2 border-white">Nombres y apellidos</th>
                    <th class="sticky top-0 z-10 px-3 py-3 text-left bg-gray-200 border-r-2 border-white">Género</th>
                    <th class="sticky top-0 z-10 px-3 py-3 text-left bg-gray-200 border-r-2 border-white">Grado</th>
                    <th class="sticky top-0 z-10 px-3 py-3 text-left bg-gray-200 border-r-2 border-white">Días Esperados</th>
                        {{-- <th class="sticky top-0 z-10 px-3 py-3 text-left bg-gray-200">Programa</th> --}}
                    @foreach ($diasSemana as $diaNombre => $fechaDia)
                        <th class="sticky top-0 left-0 z-20 px-2 py-3 text-center bg-gray-200 whitespace-nowrap border-r-2 border-white">
                            @php
                                $abreviaturas = ['Lunes'=>'Lun','Martes'=>'Mar','Miércoles'=>'Mié','Jueves'=>'Jue','Viernes'=>'Vie'];
                            @endphp
                            {{ $abreviaturas[$diaNombre] ?? mb_substr($diaNombre, 0, 3) }}
                            <span class="block text-xxs">{{ \Carbon\Carbon::parse($fechaDia)->format('d') }}</span>
                        </th>
                    @endforeach
                    <th class="sticky top-0 z-10 px-3 py-3 text-center bg-gray-200 border-r-2 border-white">Total P.</th>
                    <th class="sticky top-0 z-10 px-3 py-3 text-center bg-gray-200 border-r-2 border-white">% Asist.</th>
                </tr>
            </thead>
            <tbody class="divide-y divide-gray-200 ">
                @foreach ($participantes as $participante)
                    <tr class="group" id="fila-participante-{{ $participante->participante_id }}">
                        <td class="sticky left-0 z-10 px-4 py-3 text-gray-900  whitespace-nowrap bg-white group-hover:bg-sky-100">
                            {{ $participante->primer_nombre_p }} {{ $participante->segundo_nombre_p ?? '' }} {{ $participante->primer_apellido_p }} {{ $participante->segundo_apellido_p ?? '' }}
                            <span class="ml-2 text-xs save-feedback"></span>
                        </td>
                        <td class="px-3 py-3 text-gray-600 group-hover:bg-sky-100">{{ $participante->genero }}</td>
                        <td class="px-3 py-3 text-gray-600 group-hover:bg-sky-100">{{ $participante->grado_p ?? 'N/A' }}</td>
                        {{-- <td class="px-3 py-3 text-gray-600">{{ $participante->programa ?? 'N/A' }}</td> --}}
                        <td class="px-3 py-3 text-xs text-gray-600 group-hover:bg-sky-100">
                            @if($participante->dias_de_asistencia_al_programa)
                                @php
                                    $diasEsperados = explode(',', $participante->dias_de_asistencia_al_programa);
                                @endphp
                                @foreach($diasEsperados as $de)
                                    @php
                                        $dia = strtolower(trim($de));
                                        $color = match($dia) {
                                            'lunes' => 'bg-red-200',
                                            'martes' => 'bg-yellow-200',
                                            'miércoles', 'miercoles' => 'bg-green-200',
                                            'jueves' => 'bg-blue-200',
                                            'viernes' => 'bg-purple-200',
                                            default => 'bg-gray-200',
                                        };
                                    @endphp
                                    <span class="inline-block px-1 py-0.5 {{ $color }} rounded text-xs mr-1">
                                        {{ mb_substr(ucfirst($dia), 0, 3) }}
                                    </span>
                                @endforeach
                            @else
                                N/A
                            @endif
                        </td>


                        @foreach ($diasSemana as $diaNombre => $fechaDia)
                            <td class="px-2 py-3 text-center group-hover:bg-sky-100">
                                @php
                                    $estado = $asistencias[$participante->participante_id][$diaNombre] ?? 'Ausente';
                                    $color = match($estado) {
                                        'Presente' => 'bg-green-200',
                                        'Justificado' => 'bg-yellow-200',
                                        'Ausente' => 'bg-red-200',
                                        default => 'bg-white',
                                    };
                                @endphp

                                <select name="asistencia_individual"
                                    class="w-10 p-1 text-xs border-gray-300 rounded-3xl focus:border-blue-500 focus:ring-indigo-500 asistencia-select {{ $color }}"
                                    data-participante-id="{{ $participante->participante_id }}"
                                    data-fecha-asistencia="{{ $fechaDia }}"
                                    data-dia-nombre="{{ $diaNombre }}">
                                    <option value="Presente" {{ $estado == 'Presente' ? 'selected' : '' }}>P</option>
                                    <option value="Ausente" {{ $estado == 'Ausente' ? 'selected' : '' }}>A</option>
                                    <option value="Justificado" {{ $estado == 'Justificado' ? 'selected' : '' }}>J</option>
                                </select>

                            </td>
                        @endforeach
                        <td class="px-3 py-3 text-center total-asistido group-hover:bg-sky-100" data-participante-id="{{ $participante->participante_id }}">{{ $participante->totalAsistido ?? 0 }}</td>
                        <td class="px-3 py-3 text-center porcentaje-asistencia group-hover:bg-sky-100" data-participante-id="{{ $participante->participante_id }}">{{ $participante->porcentajeAsistencia ?? 0 }}%</td>
                    </tr>
                @endforeach
            </tbody>
        </table>
    </div>
@else
    <div class="p-6 mt-6 text-sm text-gray-500 bg-white rounded-3xl shadow-sm">
        Seleccione todos los filtros (Programa, Lugar, Grado y Semana) para cargar la lista de participantes.
        @if(isset($selectedPrograma) && $selectedPrograma && isset($selectedLugar) && $selectedLugar && isset($selectedGrado) && $selectedGrado)
            <br>No se encontraron participantes para los filtros seleccionados.
        @endif
    </div>
@endif
