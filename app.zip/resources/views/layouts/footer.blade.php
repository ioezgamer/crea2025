{{-- filepath: resources/views/layouts/footer.blade.php --}}
<footer class="p-3 text-xs text-center text-slate-600 shrink-0 sm:p-4 sm:text-sm dark:text-slate-200">
    <p class="text-sm">© {{ date('Y') }} SistemaCREA. Todos los derechos reservados.</p>
    <p class="text-sm">Tola - Rivas, Nicaragua.</p>
</footer>
